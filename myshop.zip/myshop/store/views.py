from django.http import HttpResponse

def home(request):
    return HttpResponse("""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Royal Furniture Shop</title>
        <style>
            body {
                margin: 0;
                font-family: 'Segoe UI', sans-serif;
                background: linear-gradient(135deg, #f7f1e3, #dff9fb);
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                color: #2f3542;
            }
            .container {
                text-align: center;
                max-width: 600px;
                padding: 40px;
                background: white;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
                border-radius: 16px;
            }
            h1 {
                font-size: 40px;
                margin-bottom: 8px;
            }
            h2 {
                font-size: 22px;
                color: #57606f;
                margin-top: 0;
                margin-bottom: 20px;
            }
            p {
                font-size: 18px;
                color: #555;
            }
            .coming-soon {
                font-size: 24px;
                color: #ff4757;
                margin-top: 20px;
            }
            .whatsapp-button {
                margin-top: 30px;
                display: inline-block;
                background-color: #25D366;
                color: white;
                padding: 12px 24px;
                border-radius: 30px;
                text-decoration: none;
                font-size: 18px;
                font-weight: bold;
                transition: background 0.3s ease;
            }
            .whatsapp-button:hover {
                background-color: #20ba5a;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🪑 Royal Furniture Shop</h1>
            <h2>Magarpatta</h2>
            <p>Crafting comfort and elegance for your home.</p>
            <p class="coming-soon">🚧 Website Coming Soon 🚧</p>
            <a class="whatsapp-button" href="https://wa.me/919890507411" target="_blank">
                💬 Chat with us on WhatsApp
            </a>
        </div>
    </body>
    </html>
    """)
